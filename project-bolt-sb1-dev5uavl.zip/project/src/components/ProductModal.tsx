import React from 'react';
import { X, ShoppingCart, Minus, Plus } from 'lucide-react';
import { Product, useCart } from '../contexts/CartContext';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
}

export const ProductModal: React.FC<ProductModalProps> = ({ product, onClose }) => {
  const { addToCart, state, updateQuantity } = useCart();

  if (!product) return null;

  const cartItem = state.items.find(item => item.id === product.id);
  const currentQuantity = cartItem ? cartItem.quantity : 0;

  const handleAddToCart = () => {
    addToCart(product);
  };

  const handleQuantityChange = (newQuantity: number) => {
    if (newQuantity === 0) {
      updateQuantity(product.id, 0);
    } else {
      updateQuantity(product.id, newQuantity);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b">
          <h2 className="text-2xl font-bold text-gray-800">Product Details</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Product Image */}
            <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Product Info */}
            <div className="space-y-4">
              <div>
                <span className="inline-block bg-gray-100 text-gray-600 text-sm px-3 py-1 rounded">
                  {product.category}
                </span>
              </div>

              <h3 className="text-2xl font-bold text-gray-800">{product.name}</h3>

              <p className="text-gray-600 leading-relaxed">{product.description}</p>

              <div className="flex items-center space-x-4">
                <span className="text-3xl font-bold text-blue-600">${product.price}</span>
                <span className="text-sm text-gray-500">
                  {product.stock} in stock
                </span>
              </div>

              {/* Quantity Controls */}
              {currentQuantity > 0 && (
                <div className="flex items-center space-x-3">
                  <span className="text-sm font-medium text-gray-700">Quantity:</span>
                  <div className="flex items-center border border-gray-300 rounded-lg">
                    <button
                      onClick={() => handleQuantityChange(currentQuantity - 1)}
                      className="p-2 hover:bg-gray-100 transition-colors"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="px-4 py-2 font-medium">{currentQuantity}</span>
                    <button
                      onClick={() => handleQuantityChange(currentQuantity + 1)}
                      disabled={currentQuantity >= product.stock}
                      className="p-2 hover:bg-gray-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              )}

              {/* Add to Cart Button */}
              <button
                onClick={handleAddToCart}
                disabled={product.stock === 0}
                className="w-full bg-blue-600 text-white py-3 px-6 rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                <ShoppingCart className="w-5 h-5" />
                <span>
                  {product.stock === 0 
                    ? 'Out of Stock' 
                    : currentQuantity > 0 
                      ? 'Add More to Cart' 
                      : 'Add to Cart'
                  }
                </span>
              </button>

              {currentQuantity > 0 && (
                <p className="text-sm text-green-600 text-center">
                  {currentQuantity} item{currentQuantity !== 1 ? 's' : ''} in cart
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};