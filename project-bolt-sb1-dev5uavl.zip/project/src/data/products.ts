import { Product } from '../contexts/CartContext';

export const products: Product[] = [
  {
    id: '1',
    name: 'Wireless Bluetooth Headphones',
    price: 79.99,
    image: 'https://images.pexels.com/photos/3945667/pexels-photo-3945667.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics',
    description: 'High-quality wireless headphones with noise cancellation and 30-hour battery life.',
    stock: 15
  },
  {
    id: '2',
    name: 'Smart Fitness Watch',
    price: 199.99,
    image: 'https://images.pexels.com/photos/437037/pexels-photo-437037.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics',
    description: 'Advanced fitness tracking with heart rate monitor, GPS, and water resistance.',
    stock: 8
  },
  {
    id: '3',
    name: 'Organic Cotton T-Shirt',
    price: 29.99,
    image: 'https://images.pexels.com/photos/1020585/pexels-photo-1020585.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Clothing',
    description: 'Comfortable, sustainable organic cotton t-shirt in various colors.',
    stock: 25
  },
  {
    id: '4',
    name: 'Leather Messenger Bag',
    price: 89.99,
    image: 'https://images.pexels.com/photos/2905238/pexels-photo-2905238.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Accessories',
    description: 'Premium leather messenger bag perfect for work or travel.',
    stock: 12
  },
  {
    id: '5',
    name: 'Portable Phone Charger',
    price: 24.99,
    image: 'https://images.pexels.com/photos/4316701/pexels-photo-4316701.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics',
    description: 'Fast-charging portable battery pack with multiple USB ports.',
    stock: 30
  },
  {
    id: '6',
    name: 'Running Shoes',
    price: 119.99,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Footwear',
    description: 'Lightweight running shoes with superior cushioning and breathability.',
    stock: 18
  },
  {
    id: '7',
    name: 'Coffee Maker',
    price: 149.99,
    image: 'https://images.pexels.com/photos/4226790/pexels-photo-4226790.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Home',
    description: 'Programmable coffee maker with built-in grinder and thermal carafe.',
    stock: 6
  },
  {
    id: '8',
    name: 'Wireless Mouse',
    price: 39.99,
    image: 'https://images.pexels.com/photos/2115256/pexels-photo-2115256.jpeg?auto=compress&cs=tinysrgb&w=500',
    category: 'Electronics',
    description: 'Ergonomic wireless mouse with precision tracking and long battery life.',
    stock: 22
  }
];

export const categories = ['All', 'Electronics', 'Clothing', 'Accessories', 'Footwear', 'Home'];