import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { ProductList } from './components/ProductList';
import { ProductModal } from './components/ProductModal';
import { Cart } from './components/Cart';
import { AuthModal } from './components/AuthModal';
import { CheckoutModal } from './components/CheckoutModal';
import { CartProvider, Product } from './contexts/CartContext';
import { AuthProvider } from './contexts/AuthContext';
import { products } from './data/products';

function App() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showCart, setShowCart] = useState(false);
  const [showAuth, setShowAuth] = useState(false);
  const [showCheckout, setShowCheckout] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Filter products based on search query
  const filteredProducts = useMemo(() => {
    if (!searchQuery.trim()) return products;
    
    return products.filter(product =>
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [searchQuery]);

  const handleProductSelect = (product: Product) => {
    setSelectedProduct(product);
  };

  const handleCartClick = () => {
    setShowCart(true);
  };

  const handleAuthClick = () => {
    setShowAuth(true);
  };

  const handleCheckout = () => {
    setShowCart(false);
    setShowCheckout(true);
  };

  return (
    <AuthProvider>
      <CartProvider>
        <div className="min-h-screen bg-gray-50">
          <Header
            onCartClick={handleCartClick}
            onAuthClick={handleAuthClick}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
          />
          
          <main>
            <ProductList
              products={filteredProducts}
              onProductSelect={handleProductSelect}
            />
          </main>

          {/* Modals */}
          <ProductModal
            product={selectedProduct}
            onClose={() => setSelectedProduct(null)}
          />

          <Cart
            isOpen={showCart}
            onClose={() => setShowCart(false)}
            onCheckout={handleCheckout}
          />

          <AuthModal
            isOpen={showAuth}
            onClose={() => setShowAuth(false)}
          />

          <CheckoutModal
            isOpen={showCheckout}
            onClose={() => setShowCheckout(false)}
          />
        </div>
      </CartProvider>
    </AuthProvider>
  );
}

export default App;